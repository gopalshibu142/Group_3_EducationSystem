import React, { useState, useEffect } from 'react';

const HomePage = () => {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    // Fetch student data from the API
    const fetchStudents = async () => {
      try {
        const token = localStorage.getItem('asjswToken'); // Get the bearer token from localStorage
        const response = await fetch('http://localhost:8080/api/v1/student/all', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (response.ok) {
          const data = await response.json();
          setStudents(data);
        } else {
          console.error('Error fetching student data');
        }
      } catch (error) {
        console.error('An error occurred:', error);
      }
    };

    fetchStudents();
  }, []);

  return (
    <div>
      <h1>Student List</h1>
      <ul>
        {students.map((student) => (
          <li key={student.studentId}>
            {student.firstName} {student.lastName} ({student.email})
          </li>
        ))}
      </ul>
    </div>
  );
};

export default HomePage;
