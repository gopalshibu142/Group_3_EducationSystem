import logo from './logo.svg';
import './App.css';
import { Route, Routes } from 'react-router-dom';
import HomePage from './pages/HomePage';
import SportsNewsPage from './pages/SportsNewsPage';
import BusinessNewsPage from './pages/BusinessNewsPage';
import TechNewsPage from './pages/TechNewsPage';
import Register from './components/Register';
import LoginPage from './components/LoginPage';

function App() {
  return (
    <Routes>
      <Route exact path='/' element={<HomePage />} />
      <Route exact path='/sports' element={<SportsNewsPage />} />
      <Route exact path='/business' element={<BusinessNewsPage />} />
      <Route exact path='/tech' element={<TechNewsPage />} />
      <Route exact path='/register' element = {<Register/>}/>
      <Route exact path='/login' element = {<LoginPage/>}/>
    </Routes>
  );
}

export default App;
