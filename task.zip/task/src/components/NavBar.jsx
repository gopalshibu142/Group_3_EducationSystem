import React from 'react';

const Navbar = () => {
  return (
    <nav style={{ backgroundColor: '#007bff', color: '#fff', padding: '1rem' }}>
      <a href="/" style={{ fontSize: '1.5rem', fontWeight: 'bold', textDecoration: 'none', color: '#fff' }}>
        My School App
      </a>
      <ul style={{ listStyle: 'none', display: 'flex', gap: '1rem' }}>
        <li style={{ display: 'flex', alignItems: 'center' }}>
          <a href="/add" style={{ textDecoration: 'none', color: '#fff', transition: 'color 0.3s' }}>
            Add Student
          </a>
          {/* Add an icon here (e.g., <BsPersonPlus />) */}
        </li>
        <li style={{ display: 'flex', alignItems: 'center' }}>
          <a href="/remove" style={{ textDecoration: 'none', color: '#fff', transition: 'color 0.3s' }}>
            Remove Student
          </a>
          {/* Add an icon here (e.g., <BsPersonDash />) */}
        </li>
        <li style={{ display: 'flex', alignItems: 'center' }}>
          <a href="/update" style={{ textDecoration: 'none', color: '#fff', transition: 'color 0.3s' }}>
            Update Student
          </a>
          {/* Add an icon here (e.g., <BsPencil />) */}
        </li>
        <li style={{ display: 'flex', alignItems: 'center' }}>
          <a href="/view" style={{ textDecoration: 'none', color: '#fff', transition: 'color 0.3s' }}>
            View All Students
          </a>
          {/* Add an icon here (e.g., <BsList />) */}
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;
