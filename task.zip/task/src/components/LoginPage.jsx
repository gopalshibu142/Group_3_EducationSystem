import React, { useState } from 'react';

const RegistrationForm = () => {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch('http://localhost:8080/login', {
        method: 'POST',
      //  mode: 'no-cors', // Note: You might want to remove this for CORS to work
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData), // Send user input as JSON
      });

      if (response.ok) {
        // Handle success (e.g., show a success message)
        console.log('Registration successful!');
        //console.log(await response.json())
        
        //console.log( (await response.json())['jwtToken'])
       localStorage.setItem('jwtToken',  (await response.json())['jwtToken']);
        window.location.href = 'http://localhost:3000/'
        console.log(window.localStorage.getItem('jwtToken'))
        
      } else {
        // Handle error (e.g., show an error message)
        console.error('Registration failed.');
      }
    } catch (error) {
      console.error('An error occurred:', error);
    }
  };

  return (
    <div style={{ maxWidth: '400px', margin: '0 auto', padding: '20px', backgroundColor: '#f9f9f9', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)' }}>
      <h2 style={{ fontSize: '1.5rem', marginBottom: '20px' }}>Register</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="username"
          placeholder="Username"
          value={formData.username}
          onChange={handleChange}
          style={{ width: '100%', padding: '10px', marginBottom: '15px', border: '1px solid #ccc', borderRadius: '4px' }}
        />
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={formData.password}
          onChange={handleChange}
          style={{ width: '100%', padding: '10px', marginBottom: '15px', border: '1px solid #ccc', borderRadius: '4px' }}
        />
        <button type="submit" style={{ width: '100%', padding: '10px', backgroundColor: '#007bff', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer', transition: 'background-color 0.3s' }}>
          Login
        </button>
      </form>
    </div>
  );
};

export default RegistrationForm;
